<?php

use PHPUnit\Framework\TestCase;
use MarcL\AmazonAPI;

class AmazonAPITest extends TestCase {
    public function testShouldThrowExceptionIfMissingKeyId() {
        $this->assertEquals(true, true);
    }
}
?>