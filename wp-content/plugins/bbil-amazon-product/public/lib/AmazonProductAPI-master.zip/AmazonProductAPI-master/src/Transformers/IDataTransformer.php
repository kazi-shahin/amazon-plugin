<?php

namespace MarcL\Transformers;

interface IDataTransformer {
	public function execute($data);
}

?>